$("#btnArtistas").click(function(){
    $.ajax({
        url: "acciones.php",
        type: "POST",
        data: {
            accion: "mostrar_artistas"
        },
        success: function (respuesta){
            $("#resultado").html(respuesta);
        }
    })
})

$("#btnCanciones").click(function(){
    let artista=document.getElementById("artista").value;
    $.ajax({
        url: "acciones.php",
        type: "POST",
        data: {
            accion: "mostrar_canciones",
            artista: artista
        },
        success: function (respuesta){
            $("#resultado").html(respuesta);
        }
    })
})

$("#btnRandom").click(function(){
    $.ajax({
        url: "acciones.php",
        type: "POST",
        data: {
            accion: "reproducir_random"
        },
        success: function (respuesta){
            $("#resultado").html(respuesta);
        }
    })
})