<?php
    $catalogo=[
        "The Living Tombstone" => ["Be Alone","What I Want","Orphans","Sunburn","Hit The Snooze"],
        "Siamés" => ["The Wolf","Mr. Fear","Young and Restless","Alone In The Darkness","The Phoenix"],
        "Good Kid" => ["Summer","Premier Inn","Mimi's Delivery Service","Bubbly","First Rate Town"]
    ];
    $accion=$_POST["accion"] ?? "";
    $artista=$_POST["artista"] ?? "";
    $cancion=$_POST["cancion"] ?? "";

    if($accion=="mostrar_artistas"){
        echo "<h3>Artistas disponibles</h3>";
        foreach($catalogo as $nombreArtista => $listaCanciones){
            echo $nombreArtista . "<br>";
        }
    }
    if($accion=="mostrar_canciones"){
        if(array_key_exists($artista,$catalogo)){
            echo "<h3>Canciones de $artista</h3>";

            foreach($catalogo[$artista] as $unaCancion){
                echo $unaCancion . "<br>";
            }
        } else{
            echo "El artista no existe.";
        }
    }
    if($accion=="reproducir_random"){
        $artista_random=array_rand($catalogo);
        $cancion_random=array_rand($catalogo[$artista_random]);
        echo "Sonando ahora: ". $artista_random." - " . $catalogo[$artista_random][$cancion_random];
    }
?>