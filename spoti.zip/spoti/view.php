<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Spotify</title>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <link rel="stylesheet" href="spoti.css">
</head>
<body>
    <h1>Spotify</h1>
    <div>
        <button id="btnArtistas">Ver artistas disponibles</button>
        <input type="text" id="artista">

        <p>Canción:</p>
        <input type="text" name="" id="cancion">

        <hr>

        <button id="btnArtistas">Mostrar artistas</button>
        <button id="btnCanciones">Mostrar canciones de un artista</button>
        <button id="btnBuscar">Buscar si playlist existe</button>
        <button id="btnCrear">Crear playlist favorita</button>
        <button id="btnAgregar">Agregar canción</button>
        <button id="btnEliminar">Eliminar canción</button>
        <button id="btnRandom">Reproducir canción aleatoria</button>
        <button id="btnOrdenar">Ordenar playlist</button>
        <div id="resultado"></div>
    </div>
</body>
<script src="app.js"></script>
</html>